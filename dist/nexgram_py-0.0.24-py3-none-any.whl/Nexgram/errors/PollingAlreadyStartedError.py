class PollingAlreadyStartedError(Exception):
  pass