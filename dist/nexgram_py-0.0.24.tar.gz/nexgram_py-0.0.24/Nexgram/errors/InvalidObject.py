class InvalidObject:
  pass