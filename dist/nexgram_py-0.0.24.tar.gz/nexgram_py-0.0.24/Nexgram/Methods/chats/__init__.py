from .get_chat_member import GetChatMember

class Chats(
  GetChatMember,
):
  pass