class On:
  def on(self, func):
    self.on_listeners[func] = True